import traceback
import pandas as pd
from collections import OrderedDict
import subprocess
import datetime
import ipaddress
import requests
import json
import urllib3
import sys
from pprint import pprint
import argparse
import getpass
import json
import logging
import re
import requests
import time
import warnings

urllib3.disable_warnings()


def get_bios_attributes(dell_user, dell_pass, dell_server):
    bios_attributes_list = OrderedDict({})
    att_name = []
    att_value = []
    with open(dell_server) as df:
        for line in df:
            dell_ip = line.split(',')[0]
            dell_hostname = line.split(',')[1]
            response = requests.get('https://%s/redfish/v1/Systems/System.Embedded.1/Bios' % dell_ip.strip(),verify=False,auth=(dell_user, dell_pass))
            data = response.json()
            if response.status_code != 200:
                logging.error("\n- FAIL, GET command failed to get BIOS attributes, status code %s returned" % response.status_code)
                logging.error(data)
                sys.exit(0)
            
            bios_att = ["BootMode", "NodeInterleave", "LogicalProc", "ProcVirtualization", "LlcPrefetch", "ProcConfigTdp", "ProcX2Apic", "AvxIccpPregrant", "SriovGlobalEnable", "MmioAbove4Gb", "SysProfile", "MemFrequency" ,"PcieAspmL1", "ProcCStates", "UncoreFrequency", "MonitorMwait", "ProcC1E"]
            for i in data['Attributes'].items():
                attribute_name = "%s\t" % (i[0])
                for b in bios_att:
                    if b in attribute_name:
                       att_name.append(attribute_name)   
                       attribute_value = "%s\t" % (i[1])
                       att_value.append(attribute_value)
                
            for j,k in zip(att_name,att_value):
                bios_attributes_list[dell_ip.strip()+j+k] = OrderedDict({"Server_IP": dell_ip.strip() ,"Hostname": dell_hostname.strip() , "Bios_Attribute_Name": j, 'Bios_Attribute_Value': k})

        return bios_attributes_list

def get_storage_controllers(dell_user, dell_pass, dell_ip):
            response = requests.get('https://%s/redfish/v1/Systems/System.Embedded.1/Storage' % dell_ip,verify=False,auth=(dell_user, dell_pass))   
            data = response.json()
            logging.info("\n- Server controller(s) detected -\n")
            controller_list = []
            for i in data['Members']:
                value = i['@odata.id'].split("/")[-1]
                if not "AHCI.Embedded" in value:
                   controller_list.append(i['@odata.id'].split("/")[-1])
                   #print(value)
            return controller_list[0]

def perc_controllers(dell_user, dell_pass, dell_ip,raid_cont):
            response = requests.get('https://%s/redfish/v1/Systems/System.Embedded.1/Storage/%s' % (dell_ip,raid_cont),verify=False,auth=(dell_user, dell_pass))
            data = response.json()
            #return (" - PERC_Controller_Name: %s" % (data['Name']))
            return (data['Name'])


def power_status(dell_user, dell_pass, dell_ip):
            response = requests.get('https://%s/redfish/v1/Chassis/System.Embedded.1' % (dell_ip),verify=False,auth=(dell_user, dell_pass))
            data = response.json()
            return ("Power State: %s, Health Status Overall: %s" % (data['PowerState'], data['Status']['Health']))


def get_pdisk_details(dell_user, dell_pass, dell_ip):
            raid_cont = get_storage_controllers(dell_user, dell_pass, dell_ip)
            response = requests.get('https://%s/redfish/v1/Systems/System.Embedded.1/Storage/%s' % (dell_ip,raid_cont),verify=False,auth=(dell_user, dell_pass))
            data = response.json()
            if response.status_code != 200:
               logging.error("\n- FAIL, GET command failed, return code %s" % response.status_code)
               logging.error("Extended Info Message: {0}".format(response.json()))
               sys.exit(0)
            
            drive_list = []
            pdisk = []
            pdisk_str = ""
            if data['Drives'] == []:
               logging.warning("\n- WARNING, no drives detected")
               sys.exit(0)
            else:
                for i in data['Drives']:
                    drive_list.append(i['@odata.id'].split("/")[-1])
            for i in drive_list:
                logging.info("\n- Detailed information for %s -\n" % i)
                response = requests.get('https://%s/redfish/v1/Systems/System.Embedded.1/Storage/Drives/%s' % (dell_ip, i), verify=False,auth=(dell_user, dell_pass))
                data = response.json()
                try:
                    raid_type = data['RAIDType']
                    pdisk.append("Disk: %s, RaidStatus: %s, RaidType: %s,  DriveType: %s\n" % (i, data['Oem']['Dell']['DellPhysicalDisk']['RaidStatus'], data['Oem']['Dell']['DellPhysicalDisk']['RAIDType'], data['MediaType']))
                except:
                      pdisk.append("Disk: %s, RaidStatus: %s,  DriveType: %s, RaidType: No RAID Type Found\n" % (i, data['Oem']['Dell']['DellPhysicalDisk']['RaidStatus'], data['MediaType']))
            pdisk_str = '\t'.join([j for j in pdisk])
                
            return pdisk_str


def get_vdisk_details(dell_user, dell_pass, dell_ip):
            raid_cont = get_storage_controllers(dell_user, dell_pass, dell_ip)
            response = requests.get('https://%s/redfish/v1/Systems/System.Embedded.1/Storage/%s/Volumes' % (dell_ip,raid_cont),verify=False,auth=(dell_user, dell_pass))
            data = response.json()
            if response.status_code != 200:
               logging.error("\n- FAIL, GET command failed, return code %s" % response.status_code)
               logging.error("Extended Info Message: {0}".format(response.json()))
               sys.exit(0)
            vd_list = []
            if data['Members'] == []:
               logging.warning("\n- WARNING, no virtual disk detected")
               sys.exit(0)
            else:
                for i in data['Members']:
                    vd_list.append(i['@odata.id'].split("/")[-1])
            for ii in vd_list:
                if not "Enclosure" in ii:
                   response = requests.get('https://%s/redfish/v1/Systems/System.Embedded.1/Storage/Volumes/%s' % (dell_ip,ii), verify=False,auth=(dell_user, dell_pass))     
                   data = response.json()
                   try:
                      raid_type = data['RAIDType']
                      id = data['Id']
                      raid_status = data['Oem']['Dell']['DellVirtualDisk']['RaidStatus']
                      return ("ID: %s, Name: %s,  RaidType: %s, RaidStauts: %s" % (data['Id'], data['Name'], raid_type, data['Oem']['Dell']['DellVirtualDisk']['RaidStatus']))
                   except:
                          return ("Name: %s, RaidStatus: No RAID Status Found, RAIDType: No RAID Found" % (data['Name']))


def firmware_attributes(dell_user, dell_pass, dell_ip):
            device_list = {}
            req = requests.get('https://%s/redfish/v1/UpdateService/FirmwareInventory/' % (dell_ip), auth=(dell_user, dell_pass), verify=False)
            statusCode = req.status_code
            installed_devices=[]
            data = req.json()
            for i in data['Members']:
                #installed_devices = [ii[1] for ii in i.items() if "Installed" in ii[1]]
                for ii in i.items():
                    if "Installed" in ii[1]:
                        installed_devices.append(ii[1])
            #print(installed_devices)    
            for i in installed_devices:
                req = requests.get('https://%s%s' % (dell_ip, i), auth=(dell_user, dell_pass), verify=False)
                #statusCode = req.status_code
                data1 = req.json()
                data = data1['Name']
                ph = r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}"
                if (re.search(ph, data)):
                     data=data.split(" - ")
                     data=data[0]
                else:
                     data=data
                if "Integrated Remote Access Controller" in data:
                    data = data.replace('Integrated Remote Access Controller','Integrated Dell Remote Access Controller')
                else:
                    data=data
                device_list[data] = data1['Version']
                 
            return ("BIOS Version: %s,  CPLD Version: %s, IDRAC Version: %s" % (device_list['BIOS'], device_list['System CPLD'], device_list['Integrated Dell Remote Access Controller']))    

def nic_firmware(dell_user, dell_pass, dell_ip):
            device_list = {}
	    nic_list = []
	    nic_data = []
            req = requests.get('https://%s/redfish/v1/UpdateService/FirmwareInventory/' % (dell_ip), auth=(dell_user, dell_pass), verify=False)
            statusCode = req.status_code
            installed_devices=[]
            data = req.json()
            for i in data['Members']:
                for ii in i.items():
                    if "Installed" in ii[1]:
                        installed_devices.append(ii[1])
            for i in installed_devices:
                req = requests.get('https://%s%s' % (dell_ip, i), auth=(dell_user, dell_pass), verify=False)
                data1 = req.json()
                data = data1['Name']
                ph = r"([0-9a-fA-F]{2}:){5}[0-9a-fA-F]{2}"
                if (re.search(ph, data)):
                     data=data.split(" - ")
                     data=data[0]
                else:
                     data=data
                if 'Intel' in data:
                    nic_list.append(i)
            
            for j in nic_list:
                response = requests.get('https://%s%s' % (dell_ip, j), auth=(dell_user, dell_pass), verify=False)
                data2 = response.json()
                nic = data2['Oem']['Dell']['DellSoftwareInventory']['@odata.id']
                slot = nic[-16:]
                nic_data.append("Name: %s, NIC_Slot: %s, Version: %s, Health_status: %s\n" % (data2['Name'], slot, data2['Version'], data2['Status']['Health']))

            nic_data_str = '\t'.join([j for j in nic_data])			
            return (nic_data_str)

if __name__ == '__main__':
      start = time.time()
      dell_server = raw_input("Enter File Name with  Dell Server IPs:")
     #dell_servers = 'dell_servers'
      dell_user = raw_input("Enter Dell Server User:")
     #dell_user = 'root'
      dell_pass = raw_input("Enter Dell Server Password:")
     #dell_pass = 'mavenirserver'
      x = datetime.datetime.now()
      file_creation_time = x.strftime("%Y-%m-%d-%H-%M-%S")
      #print("Writing data to pre_check_{}.csv".format(file_creation_time))
      bios_list = get_bios_attributes(dell_user, dell_pass, dell_server)
      try:
          df = pd.DataFrame()
          df.to_csv("pre_check_bios_{}.csv".format(file_creation_time))
          header_flag = 'True'
          for entry in bios_list:
              output_df = pd.Series(bios_list[entry]['Server_IP'])
              output_df = output_df.reset_index().rename(columns={output_df.index.name: 'index'})
              output_df = output_df.rename(columns={output_df.columns[1]: "Server"})
              output_df['Hostname'] = bios_list[entry]['Hostname']
              output_df['Bios_Attribute_Name'] = bios_list[entry]['Bios_Attribute_Name']
              output_df['Bios_Attribute_Value'] = bios_list[entry]['Bios_Attribute_Value']
              output_df = output_df.drop('index', 1)
              if header_flag == 'True':
                  output_df = output_df.to_csv("pre_check_bios_{}.csv".format(file_creation_time), index=False, header=True)
                  header_flag = 'False'
              else:
                  output_df = output_df.to_csv("pre_check_bios_{}.csv".format(file_creation_time), mode='a', index=False, header=False)
          print("Result is stored to pre_check_bios_{}.csv".format(file_creation_time))
      except Exception as e:
          print(e.message)
          #traceback.print_exc()
          print("Error occured while writing data to csv file")
      disk_fw_attributes = OrderedDict({})
      with open(dell_server) as df:
        for line in df:
            dell_ip = line.split(',')[0]
            dell_hostname = line.split(',')[1]
            pdisk = []
            pdisk = get_pdisk_details(dell_user,dell_pass,dell_ip.strip())
            raid_cont = []
            raid_cont = get_storage_controllers(dell_user,dell_pass,dell_ip.strip())
            vdisk = []
            vdisk = get_vdisk_details(dell_user, dell_pass, dell_ip.strip())
            perc = []
            perc = perc_controllers(dell_user, dell_pass, dell_ip.strip(),raid_cont)
            fw_att = []
            fw_att = firmware_attributes(dell_user, dell_pass, dell_ip.strip())
            nic_fw = []
            nic_fw = nic_firmware(dell_user, dell_pass, dell_ip.strip())
            pw_status = []
            pw_status = power_status(dell_user, dell_pass, dell_ip.strip())

            disk_fw_attributes[dell_ip.strip()+pw_status+perc+raid_cont+pdisk+vdisk+fw_att+nic_fw]= OrderedDict({"Server_IP": dell_ip.strip() ,"Hostname": dell_hostname.strip() , "Server Health": pw_status, "PERC_Controller": perc, 'RAID_Slot': raid_cont, "Physical_Disks": pdisk, "Virtual_Disks": vdisk, "FW_Version": fw_att, "NIC_FW_Details": nic_fw})
                       
            try:
               df = pd.DataFrame()
               df.to_csv("disk_fw_details_{}.csv".format(file_creation_time))
               header_flag = 'True'
               for entry in disk_fw_attributes:
                  output_df = pd.Series(disk_fw_attributes[entry]['Server_IP'])
                  output_df = output_df.reset_index().rename(columns={output_df.index.name: 'index'})
                  output_df = output_df.rename(columns={output_df.columns[1]: "Server"})
                  output_df['Hostname'] = disk_fw_attributes[entry]['Hostname']
                  output_df['Server Health'] = disk_fw_attributes[entry]['Server Health']
                  output_df['PERC_Controller'] = disk_fw_attributes[entry]['PERC_Controller']
                  output_df['RAID_Slot'] = disk_fw_attributes[entry]['RAID_Slot']
                  output_df['Physical_Disks'] = disk_fw_attributes[entry]['Physical_Disks']
                  output_df['Virtual_Disks'] = disk_fw_attributes[entry]['Virtual_Disks']
                  output_df['FW_Version'] = disk_fw_attributes[entry]['FW_Version']
                  output_df['NIC_FW_Details'] = disk_fw_attributes[entry]['NIC_FW_Details']
                  output_df = output_df.drop('index', 1)
                  if header_flag == 'True':
                     output_df = output_df.to_csv("disk_fw_details_{}.csv".format(file_creation_time), index=False, header=True)
                     header_flag = 'False'
                  else:
                      output_df = output_df.to_csv("disk_fw_details_{}.csv".format(file_creation_time), mode='a', index=False, header=False)
                  print("Result is stored to disk_fw_details_{}.csv".format(file_creation_time))
            except Exception as e:
               print(e.message)
               #traceback.print_exc()
               print("Error occured while writing data to csv file")
      diff = time.time()-start
      print("Execution time = {}" .format(diff))         
